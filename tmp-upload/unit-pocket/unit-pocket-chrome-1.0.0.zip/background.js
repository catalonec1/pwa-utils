/* Background (MV3 service worker in Chrome, event page in Firefox).
 * MENUS is defined in menus.js: [{ id, title, tab }]. Selected text is handed to the popup via storage.session. */
const ext = typeof browser !== 'undefined' ? browser : chrome;
if (typeof importScripts === 'function' && typeof MENUS === 'undefined') importScripts('menus.js');

ext.runtime.onInstalled.addListener(() => {
  ext.contextMenus.removeAll(() => {
    for (const m of MENUS) ext.contextMenus.create({ id: m.id, title: m.title, contexts: ['selection'] });
  });
});

ext.contextMenus.onClicked.addListener(async (info) => {
  const text = info.selectionText || '';
  const m = MENUS.find(x => x.id === info.menuItemId);
  if (!text || !m) return;
  await ext.storage.session.set({ pending: { text, action: m.id, tab: m.tab, at: Date.now() } });
  try {
    await ext.action.openPopup();
  } catch (e) {
    await ext.tabs.create({ url: ext.runtime.getURL('popup.html') + '?full=1&tab=' + m.tab });
  }
});
