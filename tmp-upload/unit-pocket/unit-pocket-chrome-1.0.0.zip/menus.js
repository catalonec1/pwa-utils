var MENUS = [
  { id: 'up-convert', title: 'Convert “%s” with Unit Pocket', tab: 'units' }
];
