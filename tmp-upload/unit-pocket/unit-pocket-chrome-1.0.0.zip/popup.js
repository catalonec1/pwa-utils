(function () {
  'use strict';
  const U = Units; const P = UnitParse; const $ = Shell.$;
  const NAMES = { length: 'Length', mass: 'Mass', temperature: 'Temperature', volume: 'Volume', area: 'Area', speed: 'Speed', time: 'Time', data: 'Data', pressure: 'Pressure', energy: 'Energy', power: 'Power', angle: 'Angle', fuel: 'Fuel economy' };
  const LABEL = { C: '°C', F: '°F', K: 'K', m2: 'm²', cm2: 'cm²', km2: 'km²', ft2: 'ft²', mi2: 'mi²', m3: 'm³', mps: 'm/s', kmh: 'km/h', galUS: 'gal (US)', galUK: 'gal (UK)', floz: 'fl oz', l100: 'L/100 km', kml: 'km/L', mpgUS: 'mpg (US)', mpgUK: 'mpg (UK)', deg: '°', b: 'bit', B: 'byte', nmi: 'nautical mi', ac: 'acre', st: 'stone', t: 'tonne', kn: 'knot', wk: 'week', yr: 'year', d: 'day' };
  const DEFAULTS = { length: ['km', 'mi'], mass: ['kg', 'lb'], temperature: ['C', 'F'], volume: ['l', 'galUS'], area: ['m2', 'ft2'], speed: ['kmh', 'mph'], time: ['h', 'min'], data: ['GB', 'MB'], pressure: ['bar', 'psi'], energy: ['kcal', 'kJ'], power: ['kW', 'hp'], angle: ['deg', 'rad'], fuel: ['l100', 'mpgUS'] };
  const label = u => LABEL[u] || u;
  const num = s => Number(String(s).replace(/\s/g, '').replace(',', '.'));
  let cat = 'length';
  try { cat = localStorage.getItem('cat') || 'length'; } catch (e) { /* ignore */ }
  if (!U.CATEGORIES[cat]) cat = 'length';

  function fillUnits(sel, pick) {
    sel.innerHTML = '';
    Object.keys(U.CATEGORIES[cat].units).forEach(u => { const o = document.createElement('option'); o.value = u; o.textContent = label(u); sel.append(o); });
    sel.value = pick;
  }
  function setCat(c, from, to) {
    cat = c; try { localStorage.setItem('cat', c); } catch (e) { /* ignore */ }
    document.querySelectorAll('#cats button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.cat === c)));
    fillUnits($('from'), from || DEFAULTS[c][0]); fillUnits($('to'), to || DEFAULTS[c][1]);
    update();
  }
  function update() {
    const v = num($('val').value);
    if (!Number.isFinite(v)) { $('result').textContent = 'Enter a number'; $('all').innerHTML = ''; return; }
    $('result').textContent = U.format(U.convert(cat, $('from').value, $('to').value, v)) + ' ' + label($('to').value);
    const tb = $('all'); tb.innerHTML = '';
    Object.keys(U.CATEGORIES[cat].units).forEach(u => {
      const val = U.format(U.convert(cat, $('from').value, u, v));
      const tr = document.createElement('tr'); const a = document.createElement('td'); const b = document.createElement('td');
      a.textContent = label(u); b.textContent = val; tr.append(a, b);
      tr.addEventListener('click', () => Shell.copy(val)); tb.append(tr);
    });
  }
  U.categories(true).forEach(c => {
    const b = document.createElement('button'); b.textContent = NAMES[c]; b.dataset.cat = c;
    b.addEventListener('click', () => setCat(c)); $('cats').append(b);
  });
  ['val', 'from', 'to'].forEach(id => $(id).addEventListener('input', update));
  $('swap').addEventListener('click', () => { const f = $('from').value; $('from').value = $('to').value; $('to').value = f; update(); });
  $('result').addEventListener('click', () => Shell.copy($('result').textContent.split(' ')[0]));

  function quick(text) {
    const q = P.parseQuantity(U, text);
    if (!q) return false;
    $('val').value = String(q.value);
    if (q.cat) {
      const to = q.unit === DEFAULTS[q.cat][0] ? DEFAULTS[q.cat][1] : DEFAULTS[q.cat][0];
      setCat(q.cat, q.unit, to);
    } else update();
    return true;
  }
  $('quick').addEventListener('input', () => quick($('quick').value));

  function bases() {
    const r = P.bases($('num').value); const tb = $('baseOut'); tb.innerHTML = '';
    if (!r) { $('baseMsg').textContent = 'Enter an integer (decimal, 0x…, 0b… or 0o…).'; $('baseMsg').className = 'hint err'; return; }
    $('baseMsg').textContent = 'Arbitrary size integers. Click a row to copy.'; $('baseMsg').className = 'hint';
    [['Decimal', r.dec], ['Hexadecimal', r.hex], ['Binary', r.bin], ['Octal', r.oct]].forEach(([k, v]) => {
      const tr = document.createElement('tr'); const a = document.createElement('td'); const b = document.createElement('td');
      a.textContent = k; b.textContent = v; b.style.wordBreak = 'break-all'; tr.append(a, b);
      tr.addEventListener('click', () => Shell.copy(v)); tb.append(tr);
    });
  }
  $('num').addEventListener('input', bases);

  window.onPending = p => { $('quick').value = p.text.trim().slice(0, 60); if (!quick(p.text)) { $('num').value = p.text.trim(); bases(); Shell.selectTab('bases'); } };
  setCat(cat); bases();
  Shell.init();
})();
