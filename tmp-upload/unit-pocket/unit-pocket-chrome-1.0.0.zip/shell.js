/* Shared popup shell: tabs, toast, clipboard, full-tab mode, support link, context-menu hand-off. */
(function (global) {
  'use strict';
  const ext = typeof browser !== 'undefined' ? browser : (typeof chrome !== 'undefined' ? chrome : null);
  const SUPPORT_URL = 'https://catalonec1.github.io/Gr-dina-de-stele/extensions/support.html';
  const $ = id => document.getElementById(id);
  const params = new URLSearchParams(location.search);

  function toast(msg) {
    const t = $('toast'); if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 1400);
  }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); }
    catch (e) {
      const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta);
      ta.select(); document.execCommand('copy'); ta.remove();
    }
    toast('Copied');
  }
  function selectTab(name) {
    document.querySelectorAll('nav [data-tab]').forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === name)));
    document.querySelectorAll('main > section[role="tabpanel"]').forEach(s => { s.hidden = s.id !== 'tab-' + name; });
    try { localStorage.setItem('tab', name); } catch (e) { /* ignore */ }
    if (global.onTab) global.onTab(name);
  }
  function openUrl(url) {
    if (ext && ext.tabs) ext.tabs.create({ url }); else window.open(url, '_blank', 'noopener');
  }
  function init() {
    if (params.get('full')) document.body.classList.add('fulltab');
    document.querySelectorAll('nav [data-tab]').forEach(b => b.addEventListener('click', () => selectTab(b.dataset.tab)));
    let start = params.get('tab');
    try { start = start || localStorage.getItem('tab'); } catch (e) { /* ignore */ }
    if (!start || !document.querySelector(`nav [data-tab="${start}"]`)) start = document.querySelector('nav [data-tab]').dataset.tab;
    selectTab(start);
    const full = $('openTab');
    if (full) {
      if (document.body.classList.contains('fulltab')) full.hidden = true;
      full.addEventListener('click', () => { openUrl((ext && ext.runtime ? ext.runtime.getURL('popup.html') : 'popup.html') + '?full=1'); window.close(); });
    }
    const sup = $('support');
    if (sup) sup.addEventListener('click', e => { e.preventDefault(); openUrl(SUPPORT_URL); });
    document.querySelectorAll('[data-copy]').forEach(b => b.addEventListener('click', () => {
      const el = $(b.dataset.copy); copy('value' in el && el.tagName !== 'PRE' ? el.value : el.textContent);
    }));
    // Hand-off from the context menu (background stores the selection, then opens the popup).
    if (ext && ext.storage && ext.storage.session) {
      ext.storage.session.get('pending').then(r => {
        const p = r && r.pending;
        if (p && Date.now() - p.at < 60000 && global.onPending) {
          ext.storage.session.remove('pending');
          if (p.tab) selectTab(p.tab);
          global.onPending(p);
        }
      }).catch(() => {});
    }
  }
  global.Shell = { ext, toast, copy, selectTab, init, $, SUPPORT_URL };
})(typeof window !== 'undefined' ? window : globalThis);
